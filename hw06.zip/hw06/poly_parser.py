#!/usr/bin/python

#################################################
# module: poly_parser.py
# bugs to vladimir dot kulyukin in canvas
#################################################
from maker import maker
import re

class poly_parser(object):

    @staticmethod
    def parse_elt(elt):
        # let's make sure that elt is a string.
        assert isinstance(elt, str)
        els = re.split('([a-zA-Z^])', elt)
        # print(els)
        const = float(els[0])
        exp = float(els[4])
        poly = maker.make_prod(maker.make_const(const),
                               maker.make_pwr(els[1], exp))
        print(poly)
        return poly

    @staticmethod
    def parse_sum(poly_str):
        assert isinstance(poly_str, str)
        els = re.split('[+]', poly_str)
        if len(els) < 2:
            return poly_parser.parse_elt(poly_str)
        if len(els) == 2:
            return maker.make_plus(poly_parser.parse_elt(els[0]), poly_parser.parse_elt(els[1]))
        # if len(els) > 2:
        #     holder = None
        #     for e in els:
        #         holder += poly_parser.parse_elt(e)



        

    
        
        
