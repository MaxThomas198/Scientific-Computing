###################################
## module: cs3430_s22_midterm02.py
## YOUR NAME
## YOUR A-NUMBER
#####################################

import math
import numpy as np
import matplotlib.pyplot as plt
## YOUR IMPORTS

## ========= Problem 1 ========================

def lambdify(s):
    ## your code here
    pass

## ========== Problem 2 ========================

def diff(s):
    ## your code here
    pass

## ========== Problem 3 ========================

def nra_approx(s, x, num_iters=5):
    ## your code here
    pass

## ========== Problem 4 ========================

def cdd_drv1_ord2(f, x, h):
    ### your code here
    pass

def cdd_drv1_ord4(f, x, h):
    ### your code here
    pass

def cdd_drv2_ord2(f, x, h):
    ### your code here
    pass

def cdd_drv2_ord4(f, x, h):
    ### your code here
    pass

### ========= Problem 5 =========================

'''
Use this format to type-draw your solution.

          R(3,3)          -- Level 3
         /      \
    R(2,2)      R(3,2)    -- Level 2
    /    \     /    \
 T(1,1)   T(2,1)   T(3,1) -- Level 1

'''

## ========== Problem 6 ========================

def plot_fourier_nth_partial_sum(f, fstr, num_points=10000, num_coeffs=3, rn=15):
    ### your code here
    pass

def plot_fourier_nth_partial_sum_error(f, fstr, num_points=10000, num_coeffs=3, rn=15):
    ### your code here
    pass

### =============== Problem 7 =========================

"""
Type your solution to Problem 7
"""

### =============== Problem 8 =========================

"""
Type your solution to Problem 8
"""
