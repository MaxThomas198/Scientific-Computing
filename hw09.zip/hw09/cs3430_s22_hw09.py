#!/usr/bin/python
# -*- coding: utf-8 -*-

######################################
# module: cs3430_s22_hw09.py
# description: cs3430 s22 hw09
# YOUR NAME
# YOUR A#
# bugs to vladimir kulyukin in canvas
######################################

def make_equiv_class_mod_n(a, n):
    """
    make_equiv_class_mod_n(a, n) returns a generator object
    to generate [a]_n (i.e., the equivalence class of a modulo n).
    """
    assert n > 0
    def gen_equiv_class(k):
        kk = k
        while True:
            yield a + kk*n
            if kk == 0:
                kk += 1
            elif kk > 0:
                kk *= -1
            elif kk < 0:
                kk *= -1
                kk += 1
    return gen_equiv_class(0)

def xeuc(a,b):
    """
    extended euclid algo that returns g, x, y such 
    g = gcd(a,b) and g = ax + by.
    """
    ### your code here
    pass

def mult_inv_mod_n(a, n):
    """
    compute the multiplicative inverse of a mod n.
    """
    ### your code here
    pass

def solve_cong(a, b, m, tmax=10):
    """
    solves the congruence ax <> b (mod m);
    returns at most tmax equivalence classes.
    """
    ### your code here
    pass

